package group.ACupOfJava.service;

/**
 * ClassName:SeatService
 * Packeage:group.ACupOfJava.service
 *
 * @Date:2020/11/26 8:36
 */
public interface SeatService {
}
