package group.ACupOfJava.dao;

/**
 * ClassName:SeatDao
 * Packeage:group.ACupOfJava.dao
 *
 * @Date:2020/11/26 8:35
 */
public interface SeatDao {
}
