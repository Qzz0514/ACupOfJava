package group.ACupOfJava.service;

import group.ACupOfJava.pojo.Activitys;

/**
 * ClassName:ActivityService
 * Packeage:group.ACupOfJava.service
 *
 * @Date:2020/12/6 8:26
 */
public interface ActivityService {
    public Activitys findActivtyById(int shop_id);
}
