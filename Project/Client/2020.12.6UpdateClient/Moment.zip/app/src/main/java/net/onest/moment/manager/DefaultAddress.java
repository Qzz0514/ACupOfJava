package net.onest.moment.manager;

/*qzz：固定地址*/
public class DefaultAddress {
    public static final String DEFAULT_ADDRESS = "http://123.57.63.212:8080/yike/";
}
