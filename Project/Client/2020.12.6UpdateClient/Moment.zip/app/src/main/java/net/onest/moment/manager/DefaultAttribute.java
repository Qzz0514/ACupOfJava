package net.onest.moment.manager;

/*qzz：固定属性*/
/*接收服务端返回数据*/
/*静态的固定值，可以直接调用*/
public class DefaultAttribute {

    public static int DEFAULT_userID; //用户id
    public static String DEFAULT_userHEADURL; //用户头像
    public static String DEFAULT_userEMAIL; //用户邮箱
    public static String DEFAULT_userNAME; //用户名
    public static String DEFAULT_sellerNAME; //商家名
    public static String DEFAULT_sellerHEAD; //商家头像


}
