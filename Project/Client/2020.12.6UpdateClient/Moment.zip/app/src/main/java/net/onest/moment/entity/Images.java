package net.onest.moment.entity;

import android.graphics.Bitmap;

import java.util.List;

public class Images {
    public static List<Bitmap> bitmaps;
}
