package net.onest.moment.manager;

/*sxh：固定地址*/
public class ServerConfig {
    public final static String SERVER_HOME = "http://192.168.56.1:8080/yike/";
}
